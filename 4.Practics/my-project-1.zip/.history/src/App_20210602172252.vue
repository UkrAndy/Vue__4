<template>
  <div>
    <!-- 3.Використовуємо компонент, як новий тег -->
<task-card
  :category="tasksList[0].category"
  :title="tasksList[0].title"
  :users="tasksList[0].users"
/>
  </div>
</template>

<script>
//1. Імпортуємо файл
import TaskCard from "./components/TaskCard";

export default {
  name: 'App',
  components: {
  //2.Реєстрація
  TaskCard
  },

  data() {
    return {
      tasksList: [
       {
         id:1,
         category:1,
         title:'Meeting',
         users:[
           {
             name:'Ivan',
             photo:'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/User_icon-cp.svg/1200px-User_icon-cp.svg.png'
           },
           {
             name:'Petro',
             photo:'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/User_icon-cp.svg/1200px-User_icon-cp.svg.png'
           },
         ]
       },
       {
         id:2,
         category:2,
         title:'Coffebreak',
         users:[
           {
             name:'Ivan',
             photo:'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/User_icon-cp.svg/1200px-User_icon-cp.svg.png'
           },
           {
             name:'Petro',
             photo:'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/User_icon-cp.svg/1200px-User_icon-cp.svg.png'
           },
          {
             name:'Sidor',
             photo:'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/User_icon-cp.svg/1200px-User_icon-cp.svg.png'
           },
         ]
       },
       
      ]
    }
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
