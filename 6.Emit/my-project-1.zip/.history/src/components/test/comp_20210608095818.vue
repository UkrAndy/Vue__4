<template>
    <div>
        <div :class="$style.class1">
                TEST
        </div>
    </div>
</template>

<script>
    export default {
        name:'Comp',

    }
</script>

<style lang="scss" module>
.class1{
    color:red
}
</style>