<template>
    <div class="main-container">
        <div>{{title}}</div>
        <div class="tasks-container">
            <task-card
            v-for="task in tasksList" :key="task.id"
              :category="task.category"
              :title="task.title"
              :users="task.users"
              @doo="val=>onDo(val)"
            />
        </div>
    </div>
</template>

<script>
//1
import TaskCard from "./components/TaskCard";
    export default {
        name:'TaskViewer',
        components: {
            //2
            TaskCard
        },

        props: {
            title: {
                type: String,
                default: 'Tasks list'
            },
            tasksList:{
                type:Array,
                default:()=>[]
            }
        },

        methods: {
            onDo(val) {
                console.log(val);
            }
        },
    }
</script>

<style lang="css" scoped>
.main-container{
    width: 320px;
    padding: 10px;
    background-color: grey;
}
</style>