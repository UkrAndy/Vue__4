<template>
  <div id="app">
    <!-- 3.Використовуємо компонент, як новий тег -->
  <table-list :products-list="productList"/>
  <table-list :products-list="productList2"/>
  </div>
</template>

<script>
//1. Імпортуємо файл
import TableList from "./components/TableList";

export default {
  name: 'App',
  components: {
  //2.Реєстрація
  TableList
  },

  data() {
    return {
      productList: [
       {
         id:1,
         title:'Tomatos',
         price:25
       },
       {
         id:2,
         title:'Tomatos2',
         price:251
       },
       {
         id:3,
         title:'Tomatos3',
         price:252
       },
        
      ],
      productList2: [
       {
         id:1,
         title:'qqqqqTomatos',
         price:25
       },
       {
         id:2,
         title:'qqqqTomatos2',
         price:251
       },
       {
         id:3,
         title:'qqqqqTomatos3',
         price:252
       },
        
      ]
    }
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
