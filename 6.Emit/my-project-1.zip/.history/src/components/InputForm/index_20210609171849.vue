<template>
    <div class="input-form">
      <label >
          Title 
          <input type="text" v-model="title">
      </label>
      <label >
          Price 
          <input type="number" v-model.number="price">
      </label>
      <button @click="onAdd">Add</button>
    </div>
</template>

<script>
    export default {
        name:'InputForm',
        data() {
            return {
                      title:null,
      price:null,
            }
        },
    }
</script>

<style lang="scss" scoped>

</style>