<template>
  <div id="app">
    <!-- 3.Використовуємо компонент, як новий тег -->
    <MyComp/>
    <Comp2/>
  </div>
</template>

<script>
//1. Імпортуємо файл
import MyComp from "./components/MyComp";
import Comp2 from "./components/Comp2";

export default {
  name: 'App',
  components: {
  //2.Реєстрація
  MyComp,
  Comp2
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
