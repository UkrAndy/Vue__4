<template>
    <div>

    </div>
</template>

<script>
    export default {
        name:'MyCalc2'
    }
</script>

<style lang="scss" scoped>

</style>