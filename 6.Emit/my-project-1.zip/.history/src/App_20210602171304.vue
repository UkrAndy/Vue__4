<template>
  <div id="app">
    <!-- 3.Використовуємо компонент, як новий тег -->
  <table-list :products-list="productList"/>
  <table-list :products-list="productList2"/>
  </div>
</template>

<script>
//1. Імпортуємо файл
import TableList from "./components/TableList";

export default {
  name: 'App',
  components: {
  //2.Реєстрація
  TableList
  },

  data() {
    return {
      tasksList: [
       {
         id:1,
         category:1,
         title:'Metting',
         users:[
           {
             name:'Ivan',
             photo:'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/User_icon-cp.svg/1200px-User_icon-cp.svg.png'
           },
           {
             name:'Ivan',
             photo:'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/User_icon-cp.svg/1200px-User_icon-cp.svg.png'
           },
         ]
       },
       {
         id:2,
         category:2,
         title:'Coffebreak',
         users:[
           {
             name:'Ivan',
             photo:'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/User_icon-cp.svg/1200px-User_icon-cp.svg.png'
           },
           {
             name:'Petro',
             photo:'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/User_icon-cp.svg/1200px-User_icon-cp.svg.png'
           },
          {
             name:'Sidor',
             photo:'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/User_icon-cp.svg/1200px-User_icon-cp.svg.png'
           },
         ]
       },
       
      ]
    }
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
