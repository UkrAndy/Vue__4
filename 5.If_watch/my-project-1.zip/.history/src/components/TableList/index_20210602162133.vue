<template>
    <div>
        <h1>{{message}}</h1>
        <table class="table-list">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="prod in productsList" :key="prod.id">
                    <td>{{prod.title}}</td>
                    <td>{{prod.price}}</td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<script>
const message='Hello'
    export default {
        name:'TableList',

        props: {
            productsList: {
                type: Array,
                default: () => []
            },
        },

    }
</script>

<style lang="css" scoped>
.table-list{
    border: 2px solid black;
}
</style>