<template>
    <div>

    </div>
</template>

<script>
    export default {
        name:'ProductTable',
        props: {
            userMoney: {
                type: Number,
                default: 0
            },
            products: {
                type: Array,
                default: ()=>[]
            },
        },
    }
</script>

<style lang="scss" scoped>

</style>