<template>
    <div>
        <child-comp :title="11111" :class-p="$style.class1"/>
        <child-comp :title="22222" :class-p="$style.class2"/>
        <div :class="$style.class1">
                TEST
        </div>
    </div>
</template>

<script>
import ChildComp from "./ChildComp";
    export default {
        name:'Comp',
        data1:23,
        components: {
            ChildComp,
        },

    }
</script>

<style lang="scss" module>
.class1{
    color:red
}
.class2{
    color:green
}
</style>