<template>
<div>
    <label >
        Product:
        <input type="text" v-model="searchProduct">
    </label>
    <label >
        Price:
        <input type="number" v-model="searchPrice">
    </label>
    <table v-if="filteredProducts.length>0" border="2px">
        <tr>
            <th>Title</th>
            <th>Price</th>
            <th>Options</th>
        </tr>
        <tr v-for="product in filteredProducts" :key="product.id">
            <td :class="getProductClass(product)" >
                {{product.title}}</td>
            <td>{{product.price}}</td>
            <td>
                <span v-if="product.price<=userMoney"><button>Купити</button> </span>
                <span v-else>Не вистачає: {{userMoney-product.price}} </span>
                <!-- <span v-show="product.price<=userMoney"><button>Купити</button> </span> -->
                <!-- <span v-else> {{`Не вистачає: ${userMoney-product.price}`}} </span> -->
            </td>
        </tr>
    </table>
    <div v-else>
        No items
    </div>
    </div>
</template>

<script>
    export default {
        name:'ProductTable',
        props: {
            userMoney: {
                type: Number,
                default: 0
            },
            products: {
                type: Array,
                default: ()=>[]
            },
        },
        data() {
            return {
                searchProduct: null,  //Змінна де зберігаємо назву товару, що шукаємо
                filteredProducts:this.products,
                searchPrice: null
            }
        },
        watch: {  //Розділ, у якому записуємо змінні, зміну яких відслідковуємо
            searchProduct() { //Функція, яка буде викликатися коли значення "searchProduct" буде змінено
                        // "newValue" - нове значення змінної "searchProduct"
                this.filterProducts()
            },
            searchPrice() {
                this.filterProducts()
            }
        },
        methods: {
            getProductClass(product) {
                return product.price<=this.userMoney?'can-buy':'can-not-buy' 
            },
            filterProducts() {
                const val=this.searchProduct.toLowerCase()
            
                this.filteredProducts=this.products.filter(product=>(
                    (!val || product.title.toLowerCase().startsWith(val)) && 
                    (!this.searchPrice || product.price<=parseFloat(this.searchPrice))))
            }
        },
    }
</script>

<style lang="css" scoped>
.can-buy{
    color:green
}
.can-not-buy{
    color:red
}
</style>