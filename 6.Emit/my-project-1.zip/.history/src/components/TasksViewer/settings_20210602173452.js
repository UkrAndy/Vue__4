export const categories = {
  0: 'Metting',
  1: 'Webinar',
  2: 'Email',
}
