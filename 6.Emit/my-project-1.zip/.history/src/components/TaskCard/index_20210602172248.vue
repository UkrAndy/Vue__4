<template>
<div class="container">
<div>
    <div class="tag">
    </div>
    <div class="title">
        {{title}}
    </div>
    <div class="img-container">
        <img
        v-for="(user,ind) in users" :key="ind"
         :src="user.photo" :alt="user.name"
         :title="user.name"
         class="user-photo"
         >

    </div>
</div>
    </div>
</template>

<script>
    export default {
        name: 'TaskCard',
        props: {
            category: {
                type: Number,
                default: 0
            },
            title:{
                type: String,
                default: 'nulltitle'
            },
            users: {
                type: Array,
                default: () => []
            },
              
        },
    }
</script>

<style lang="css" scoped>
.container{
    border-radius: 8px;
    border:2px solid green;
    width: 300px;
    padding: 10px;
}
.tag{
  border-radius: 8px;
  width: 40px;
  height: 16px;
  background-color: red;
}
.user-photo{
    border-radius: 50%;
    height: 50px;
}
.img-container{
    text-align: right;
}
</style>