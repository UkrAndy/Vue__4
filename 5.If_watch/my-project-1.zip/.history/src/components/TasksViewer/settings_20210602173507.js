export const categories = {
  0: 'Meeting',
  1: 'Webinar',
  2: 'Email',
}
