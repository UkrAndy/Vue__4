<template>
    <div>
        <label>
            Number 1
            <input type="number" v-model="num1">
        </label>
                <label>
            Number 2
            <input type="number" v-model="num2">
        </label>
        <button>
            Add
        </button>
           </label>
                <label>
            Summ
            <input type="number" v-model="resSum">
        </label>     
    </div>
</template>

<script>
    export default {
        name:'MyCalc',
        data() {
            return {
                num1: 0,
                num2: 0,
            }
        },

    }
</script>

<style lang="scss" scoped>

</style>