<template>
    <div class="input-form">
      <label >
          Title 
          <input type="text" v-model="title">
      </label> <br>
      <label >
          Price 
          <input type="number" v-model.number="price">
      </label><br>
      <button @click="onAddItem">Add</button>
    </div>
</template>

<script>
    export default {
        name:'InputForm',
        data() {
            return {
                title:null,
                price:null,
            }
        },
        methods: {
            onAddItem() {
                this.$emit('add',
                 {
                     title:this.title,
                     price:this.price
                 }
                )
            }
        },
    }
</script>

<style lang="scss" scoped>

</style>