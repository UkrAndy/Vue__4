<template>
    <div>
        <div :class="classP">
                {{title}}
        </div>
    </div>
</template>

<script>
    export default {
        name:'ChildComp',
        props: {
            title:{
                type:String,
                default:''
            },
            classP: {
                type: String,
                default: null
            },
        },
    }
</script>

<style lang="scss" module>
.class1{
    color:red
}
</style>