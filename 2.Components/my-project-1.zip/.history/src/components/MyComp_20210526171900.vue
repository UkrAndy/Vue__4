<template>
    <div>
        Доброго дня!
    </div>
</template>

<script>
    export default {
        name:'MyComp'
    }
</script>

<style lang="scss" scoped>

</style>