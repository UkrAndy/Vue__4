<template>
    <div>
        <child-comp title="11111" :class-p="$style.class1"/>
        <child-comp title="22222" :class-p="$style.class2"/>
        <div :class="$style.class1">
                TEST {{msg}}
        </div>
        <button @click="onClick">okk</button>
    </div>
</template>

<script>
import ChildComp from "./ChildComp";
    export default {
        name:'Comp',
        data1:23,
        data() {
            return {
                msg:''
            }
        },
        components: {
            ChildComp,
        },
methods: {
    onClick() {
        console.log(this.$options.data1);
        this.msg=this.$options.data1
        this.$options.data1++
    }
},
    }
</script>

<style lang="scss" module>
.class1{
    color:red
}
.class2{
    color:green
}
</style>