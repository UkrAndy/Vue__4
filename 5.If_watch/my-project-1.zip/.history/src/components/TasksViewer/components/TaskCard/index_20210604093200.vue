<template>
<div class="container">
<div>
    <div class="tag">
    </div>
    <div class="title">
        {{title}}
    </div>
    <div class="img-container">
        <img
        v-for="(user,ind) in users" :key="ind"
         :src="user.photo" :alt="user.name"
         :title="user.name"
         class="user-photo"
         >

    </div>
    <div>
        User name: {{currentUser.name}}
    </div>
    <div>
        <button @click="onPrevClick">Prev</button>
        <button  @click="onNextClick">Next</button>
        <button  @click="$emit('doo',123)">Do</button>

    </div>
</div>
    </div>
</template>

<script>
    export default {
        name: 'TaskCard',
        props: {
            category: {
                type: Number,
                default: 0
            },
            title:{
                type: String,
                default: 'nulltitle'
            },
            users: {
                type: Array,
                default: () => []
            },
            testOb:{
                type:Object,
                default:()=>{}
            }
              
        },
        data1:123,
        data() {
            return {
                currentUserIndex:0
            }
        },
        computed: {
            currentUser() {
                return this.users[this.currentUserIndex] 
            }
        },
        methods: {
            onPrevClick() {
                this.currentUserIndex--
                if(this.currentUserIndex<0)
                    this.currentUserIndex=this.users.length-1
                console.log('this.$options.data1');
                console.log(this.$options);
            },
            onNextClick(){
                this.currentUserIndex++
                if(this.currentUserIndex>=this.users.length)
                    this.currentUserIndex=0
            }
        },
        mounted () {
            console.log('this.testOb');
            console.log(this.testOb);
        },
    }
</script>

<style lang="css" scoped>
.container{
    border-radius: 8px;
    border:2px solid green;
    width: 300px;
    padding: 10px;
}
.tag{
  border-radius: 8px;
  width: 40px;
  height: 16px;
  background-color: red;
}
.user-photo{
    border-radius: 50%;
    height: 50px;
}
.img-container{
    text-align: right;
}
</style>