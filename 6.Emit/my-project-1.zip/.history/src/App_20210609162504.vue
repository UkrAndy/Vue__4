<template>
  <div>
    <div class="input-form">
      <label >
          Title 
          <input type="text" v-model="title">
      </label>
      <label >
          Price 
          <input type="number" v-model.number="price">
      </label>
      <button @click="onAdd">Add</button>
    </div>
    <!-- 3.Використовуємо компонент, як новий тег -->
   <product-table
     :user-money="5000"
     :products="dataProductsList"
   />

  </div>
</template>

<script>
import { v4 as uuidv4 } from 'uuid';

//1. Імпортуємо файл
import ProductTable from "./components/ProductTable";

export default {
  name: 'App',
  components: {
  //2.Реєстрація
  ProductTable,
  },

  data() {
    return {
      title:null,
      price:null,
      dataProductsList: [
       {
         id:1,
         title:'TV',
         price:2000
       },
       {
         id:2,
         title:'Fridge',
         price:12000
       },
       {
         id:3,
         title:'TV2',
         price:34000
       },
       {
         id:4,
         title:'Fridge2',
         price:10000
       },
             
      ]
    }
  },
  methods: {
    onAdd() {
      this.dataProductsList.push({
        id:uuidv4(),
        title:this.title,
        price:this.price
      })
    }
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
