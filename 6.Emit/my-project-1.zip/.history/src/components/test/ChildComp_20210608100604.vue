<template>
    <div>
        <div :class="classP">
                {{title}}
        </div>
    </div>
</template>

<script>
    export default {
        name:'ChildComp',
        props: {
            title:{
                type:String,
                default:''
            },
            classP: {
                type: Object,
                default: null
            },
        },
    }
</script>

<style lang="scss" module>
.class1{
    color:red
}
</style>