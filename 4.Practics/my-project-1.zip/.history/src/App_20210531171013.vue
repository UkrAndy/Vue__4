<template>
  <div id="app">
    <!-- 3.Використовуємо компонент, як новий тег -->
    <product-card 
      imageSrc="https://content2.rozetka.com.ua/goods/images/preview/116580856.jpg"
      productTitle="Монитор 23.8 Asus VA24EHE"
      productLink="https://hard.rozetka.com.ua/asus_90lm0560_b01170/p184066457/"
      productPrice="3819"

    />
    <input type="text" value="">
  </div>
</template>

<script>
//1. Імпортуємо файл
import ProductCard from "./components/ProductCard";

export default {
  name: 'App',
  components: {
  //2.Реєстрація
  ProductCard
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
