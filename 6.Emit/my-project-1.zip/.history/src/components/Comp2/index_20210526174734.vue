<template>
    <div>
        <h1 class="header">Привіт!</h1>
        <p>
            Привіт усім від {{myName}}
        </p>
        <p>
            Мені {{age}}
        </p>
    </div>
</template>

<script>
    export default {
        name:'Comp2',
        data() {
            return {
                myName: 'Ivan',
                age:21
            }
        },
    }
</script>

<style lang="css" scoped>
.header{
    color: red;
}
</style>