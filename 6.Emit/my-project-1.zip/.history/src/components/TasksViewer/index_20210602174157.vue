<template>
    <div>
        <div>{{title}}</div>
        <div>
            <task-card
            v-for="task in tasksList" :key="task.id"
              :category="task.category"
              :title="task.title"
                :users="task.users"
            />
        </div>
    </div>
</template>

<script>
//1
import TaskCard from "./components/TaskCard";
    export default {
        name:'TaskViewer',
        components: {
            TaskCard
        },

        props: {
            title: {
                type: String,
                default: 'Tasks list'
            },
            tasksList:{
                type:Array,
                default:()=>[]
            }
        },
    }
</script>

<style lang="scss" scoped>

</style>