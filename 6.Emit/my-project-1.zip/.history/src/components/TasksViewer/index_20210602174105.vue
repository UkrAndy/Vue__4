<template>
    <div>
        <div>{{title}}</div>
        <div>
            <task-card
              :category="tasksList[0].category"
  :title="tasksList[0].title"
  :users="tasksList[0].users"
            />
        </div>
    </div>
</template>

<script>
//1
import TaskCard from "./components/TaskCard";
    export default {
        name:'TaskViewer',
        components: {
            TaskCard
        },

        props: {
            title: {
                type: String,
                default: 'Tasks list'
            },
            tasksList:{
                type:Array,
                default:()=>[]
            }
        },
    }
</script>

<style lang="scss" scoped>

</style>