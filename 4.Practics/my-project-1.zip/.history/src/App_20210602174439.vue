<template>
  <div>
    <!-- 3.Використовуємо компонент, як новий тег -->
   <tasks-viewer 
    title="My list"
    :tasks-list="tasksList"/>
  </div>
</template>

<script>
//1. Імпортуємо файл
import TasksViewer from "./components/TasksViewer";

export default {
  name: 'App',
  components: {
  //2.Реєстрація
  TasksViewer
  },

  data() {
    return {
      tasksList: [
       {
         id:1,
         category:1,
         title:'Meeting',
         users:[
           {
             name:'Ivan',
             photo:'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/User_icon-cp.svg/1200px-User_icon-cp.svg.png'
           },
           {
             name:'Petro',
             photo:'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/User_icon-cp.svg/1200px-User_icon-cp.svg.png'
           },
         ]
       },
       {
         id:2,
         category:2,
         title:'Coffebreak',
         users:[
           {
             name:'Ivan',
             photo:'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/User_icon-cp.svg/1200px-User_icon-cp.svg.png'
           },
           {
             name:'Petro',
             photo:'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/User_icon-cp.svg/1200px-User_icon-cp.svg.png'
           },
          {
             name:'Sidor',
             photo:'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/User_icon-cp.svg/1200px-User_icon-cp.svg.png'
           },
         ]
       },
       
      ]
    }
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
