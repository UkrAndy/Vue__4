<template>
    <div>
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="prod in productsList" :key="prod.id">
                    <td>{{prod.title}}</td>
                    <td>{{prod.price}}</td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<script>
    export default {
        name:'TableList',

        props: {
            productsList: {
                type: Array,
                default: () => []
            },
        },

    }
</script>

<style lang="scss" scoped>

</style>