<template>
    <div>
        <h1>Привіт!</h1>
        <p>
            Привіт усім
        </p>
    </div>
</template>

<script>
    export default {
        name:'Comp2'
    }
</script>

<style lang="scss" scoped>

</style>