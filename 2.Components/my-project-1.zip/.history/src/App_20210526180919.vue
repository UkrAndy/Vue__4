<template>
  <div id="app">
    <!-- 3.Використовуємо компонент, як новий тег -->
    <my-calc/>

  </div>
</template>

<script>
//1. Імпортуємо файл
import MyCalc from "./components/MyCalc";

export default {
  name: 'App',
  components: {
  //2.Реєстрація
  MyCalc
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
