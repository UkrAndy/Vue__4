<template>
  <div>
    <!-- 3.Використовуємо компонент, як новий тег -->
   <!-- <product-table
     :user-money="5000"
     :products="dataProductsList"
   /> -->
   <comp/>
   <comp/>
  </div>
</template>

<script>
//1. Імпортуємо файл
// import ProductTable from "./components/ProductTable";
import comp from "./components/test/Comp";

export default {
  name: 'App',
  components: {
  //2.Реєстрація
  // ProductTable,
  comp
  },

  data() {
    return {
      dataProductsList: [
       {
         id:1,
         title:'TV',
         price:2000
       },
       {
         id:2,
         title:'Fridge',
         price:12000
       },
       {
         id:3,
         title:'TV2',
         price:34000
       },
       {
         id:4,
         title:'Fridge2',
         price:10000
       },
             
      ]
    }
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
