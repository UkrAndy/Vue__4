<template>
  <div id="app">
    <!-- 3.Використовуємо компонент, як новий тег -->

      <product-card v-for="(item,index) in productList" :key="index"
         :image-src="item.imageSrc"
         :product-title="item.productTitle"
         :product-link="item.productLink"
        :product-price="item.productPrice"     
      
      />
  </div>
</template>

<script>
//1. Імпортуємо файл
import ProductCard from "./components/ProductCard";

export default {
  name: 'App',
  components: {
  //2.Реєстрація
  ProductCard
  },

  data() {
    return {
      
      productList: [
        {   
          id:1,           
          imageSrc:"https://content2.rozetka.com.ua/goods/images/preview/116580856.jpg",
          productTitle:"Монитор 23.8 Asus VA24EHE",
          productLink:"https://hard.rozetka.com.ua/asus_90lm0560_b01170/p184066457/",
          productPrice:"3819грн."
        },
        {   
          id:2,           
          imageSrc:"https://content2.rozetka.com.ua/goods/images/preview/15611369.jpg",
          productTitle:"Процессор AMD Ryzen 5 3600",
          productLink:"https://hard.rozetka.com.ua/amd_ryzen_5_3600/p100191625/",
          productPrice:"6659"
        }
      ]
    }
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
