<template>
  <div>
    <input-form @add="onAdd"/>
    <!-- 3.Використовуємо компонент, як новий тег -->
    <!-- :key="updateKey" використовуємо для примусового оновлення компонента -->
   <product-table
     :key="updateKey"
     :user-money="5000"
     :products="dataProductsList"
     @del="onItemDel"
   />
     <!-- @подія="обробник_події" -->
  </div>
</template>
<script>
//1. Встановити "npm install uuid"
//2. Імпортуємо функцію
import { v4 as uuidv4 } from 'uuid';

//1. Імпортуємо файл
import InputForm from "./components/InputForm";
import ProductTable from "./components/ProductTable";
export default {
  name: 'App',
  components: {
  //2.Реєстрація
  ProductTable,
  InputForm
  },
  data() {
    return {
      updateKey:0,
      dataProductsList: [
       {
         id:1,
         title:'TV',
         price:2000
       },
       {
         id:2,
         title:'Fridge',
         price:12000
       },
       {
         id:3,
         title:'TV2',
         price:34000
       },
       {
         id:4,
         title:'Fridge2',
         price:10000
       },
             
      ]
    }
  },
  methods: {
    onItemDel(productId){
      this.dataProductsList=this.dataProductsList.filter(item=>item.id!==productId)
      this.updateKey++ //Зміна цієї змінної призведе до оновлення компонента з таким клчем
    },
    onAdd({title,price}) {
      this.dataProductsList.push({
        id:uuidv4(), //3. Генеруємо унікальний ІД
        title,
        price
      })
    }
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
