<template>
    <div>
        <h1 class="header">Привіт!</h1>
        <p>
            Привіт усім
        </p>
    </div>
</template>

<script>
    export default {
        name:'Comp2'
    }
</script>

<style lang="css" scoped>
.header{
    color: red;
}
</style>