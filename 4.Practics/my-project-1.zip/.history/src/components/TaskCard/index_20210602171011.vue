<template>
    <div>
<div>
    <div class="tag">

    </div>
    <div class="title">
        {{title}}
    </div>
    <div class="img">
        <img
        v-for="(user,ind) in users" :key="ind"
         :src="user.photo" :alt="user.name"
         class="user-photo"
         >

    </div>
</div>
    </div>
</template>

<script>
    export default {
        name: 'TaskCard',
        props: {
            category: {
                type: Number,
                default: 0
            },
            title:{
                type: String,
                default: 'nulltitle'
            },
            users: {
                type: Array,
                default: () => []
            },
              
        },
    }
</script>

<style lang="css" scoped>
.tag{
  border-radius: 8px;
  width: 40px;
  height: 16px;
  border-color: red;
}
.user-photo{
    border-radius: 50%;
    height: 50px;
}
</style>