<template>
    <table>
        <tr>
            <th>Title</th>
            <th>Price</th>
            <th>Options</th>
        </tr>
        <tr v-for="product in products" :key="product.id">
            <td>{{product.title}}</td>
            <td>{{product.price}}</td>
            <td>
                <span v-if="product.price<=userMoney"><button>Купити</button> </span>
                <!-- <span v-else> {{`Не вистачає: ${userMoney-product.price}`}} </span> -->
                <span v-else>Не вистачає: {{userMoney-product.price}} </span>
            </td>
        </tr>
    </table>
</template>

<script>
    export default {
        name:'ProductTable',
        props: {
            userMoney: {
                type: Number,
                default: 0
            },
            products: {
                type: Array,
                default: ()=>[]
            },
        },
    }
</script>

<style lang="scss" scoped>

</style>